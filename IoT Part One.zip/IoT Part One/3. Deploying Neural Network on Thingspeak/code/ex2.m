
X=irisInputs(:,113);

sl=X(1);
sw=X(2);
pl=X(3);
pw=X(4);
thingSpeakWrite(1562934,{sl,sw,pl,pw},'WriteKey','5ZYINAJSD3THCT4F');

disp('exit');